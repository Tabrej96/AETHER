---
name: zero-loss-continuity
description: Interrupt-safe task state: any session (new model, new terminal, new branch, new machine) can resume exactly where the last one stopped, with evidence of what was verified and what was not.
version: 1.0.0
maturity: stable
license: MIT
budget: 0
capabilities:
  - continuity
  - recovery
prerequisites: []
# API-like protocol; loaded on demand by the checkpoint skill, not injected.
---

# Zero-Loss Continuity

## Invariants

1. **No hidden state.** Everything a task needs to resume lives in `.aether/state/` (git-ignored, versioned content in `state.json`).
2. **Checkpoint on transition, not on a timer.** A checkpoint is written when the task crosses a stage boundary (plan → implement → verify → release), never mid-stage.
3. **Evidence is first-class.** A checkpoint records *verification state*: which gates passed with which evidence (test IDs, commit, command + exit code). "I think it works" is not a checkpoint field.
4. **Monotonic sequence.** Each checkpoint bumps `seq`. Resume rejects a state file whose `seq` is lower than the last known — a corrupted/truncated checkpoint can't silently lose state.

## State file (`.aether/state.json`)

```json
{
  "task": "bench_release_tagging_v1",
  "seq": 7,
  "stage": "verify",
  "branch": "feature/release-tags",
  "base_commit": "a1b2c3d",
  "head_commit": "f9e8d7c",
  "open": [
    {"id": "O1", "desc": "verify semver-tag step under clean clone", "status": "open"}
  ],
  "verified": [
    {"gate": "tests pass", "evidence": "npm test, exit 0, commit f9e8d7c"}
  ],
  "discovered": [
    {"id": "D1", "claim": "npm ci fails on Node 20.11, needs 20.15+", "confidence": 0.8}
  ],
  "updated_at": "2026-11-12T10:00:00Z"
}
```

## Resume procedure (deterministic, no LLM in the loop)

```
load .aether/state.json
  → verify seq is monotonic vs last checkpoint file (state/checkpoint-*.json)
  → branch check: if current branch != state.branch, stop and ask (never auto-switch)
  → replay: for each "open" item, re-run its verification command if cheap (<30s), else re-plan it
  → compact: hand the model ONE summary (task, stage, open, verified-evidence) — not the whole history
```

## Failure modes the protocol names explicitly

| Event | Action |
|---|---|
| Context exhaustion | Mid-stage work is by definition not checkpointed; the checkpoint skill compacts to the last stage boundary and resumes from there. Nothing between boundaries is lost — it's re-derivable from `open` items. |
| API rate limit | Same as above; resume is idempotent. |
| Terminal closed | State is on disk; a new session runs Resume procedure. |
| Branch switch by user | Resume detects mismatch, halts, surfaces it. |
| Model failure / swap | New model gets the compacted summary only. Model identity is not part of state — AETHER is provider-agnostic by design. |
