---
name: layered-memory
description: AETHER's five-layer knowledge store with provenance, confidence, verification state, and decay. Replaces flat "session memory" with something that actually survives, decays, and gets re-verified.
version: 1.0.0
maturity: stable
license: MIT
budget: 0
capabilities:
  - memory
  - learning
prerequisites: []
# No static budget: memory is an API, not injected context. Components pull
# entries by relevance; the store never dumps itself into a prompt.
---

# Layered Engineering Memory

## Layers

| Layer | Lifetime | Promoted from | Verdict |
|---|---|---|---|
| **working** | one task | hypotheses, mid-flight facts | unverified |
| **verified** | until re-checked | working + passing regression gate | verified |
| **failure** | long-lived | post-mortems, refuted hypotheses | verified-false |
| **pattern** | until superseded | N≥2 independent verified hits | pattern |
| **architecture** | until ADR overrides | pattern + architect sign-off | ADR-anchored |

## Entry shape

```yaml
id: mem_20261112_0001
layer: verified
claim: "Order of `git` operations in release workflow matters: tag after commit, not before"
scope: ["release", "git"]
provenance:
  task: bench_release_tagging_v1
  run: run-2026-11-12a
  evidence: "tests/benchmarks/fixed/003_release.sh:tag-step"
confidence: 0.9
state: verified
verified_by: adversarial-reviewer
verified_at: 2026-11-12T00:00Z
touched: 2026-11-12T00:00Z
superseded_by: null
```

## Lifecycle

1. **write** → `working`, low confidence, evidence pointer attached.
2. **reproduce** → a second independent run confirms → promote to `verified`.
3. **refute** → a run fails where entry claims success → move to `failure` with the delta.
4. **pattern** → N (default 2) independent `verified` entries with the same claim+scope → coalesce.
5. **decay** → `verified` with no touch for T (default 30d) → demote to `working` and re-queue verification. `failure` entries do NOT decay — a documented regression is forever.
6. **supersede** → newer entry claims the same scope → old entry gets `superseded_by`, not deleted.

## API (what a hook or skill may call)

- `mem.write(layer, entry)` — always to `working` or `failure`; only the verifier writes `verified` directly.
- `mem.recall(scope, budget)` — returns top-k by relevance×confidence within a token budget; **never dumps the store**.
- `mem.verify(id)` / `mem.refute(id, delta)` — verdict transitions.
- `mem.decay(now)` — scheduled; hooks call this at session start.

## Invariants

- An entry without `provenance.evidence` is invalid (validator rejects).
- Only the independent-verifier role can set `state: verified`.
- `failure` layer is append-only until a `refute` supersedes it.
