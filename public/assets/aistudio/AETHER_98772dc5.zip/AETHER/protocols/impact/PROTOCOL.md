---
name: change-impact-analysis
description: Estimate which components a change will affect BEFORE implementing it, from AST/call-graph/dependency signal, and emit a targeted verification plan (the tests to run, in dependency order).
version: 1.0.0
maturity: experimental
license: MIT
budget: 0
capabilities:
  - impact-analysis
prerequisites: []
# The impact-analysis skill implements this protocol; the protocol names the
# signals and the determinism contract so results are reproducible.
---

# Predictive Engineering Intelligence

## Invariant: deterministic given inputs

Impact analysis must produce the **same** affected-set for the same diff + the
same repo snapshot. No LLM guesswork in the set computation. The LLM only
*interprets* the set (which file to look at first, what a coupling means).

## Signal ladder (cheapest first; use the strongest that's available)

1. **Import graph** — static: `import`/`require`/`from` edges in changed files → direct consumers. Always available.
2. **Symbol graph** — exported symbols in changed files → grep for their use sites. Available with ripgrep.
3. **Call graph** — for JS/TS/Python, cross-reference call sites (via `graphify` if installed, else symbol grep). Degrades gracefully.
4. **Test-dependency map** — for each changed symbol, find the tests that touch it (imports the module, or asserts on the symbol). This is what turns impact into a *verification plan*.
5. **Git-history co-change** — files that have historically been edited together with the changed files (via `git log --name-only`). Surfaces the "we always change X and Y together" coupling no graph sees.

## Output

```json
{
  "diff_sha": "...",
  "affected": [
    {"file": "src/order/price.ts", "reason": "imports changed symbol discount()", "signal": "import"},
    {"file": "tests/price.test.ts", "reason": "asserts on discount()", "signal": "test-dep"}
  ],
  "verify_plan": [
    {"cmd": "npx vitest run tests/price.test.ts", "order": 1, "covers": ["discount"]},
    {"cmd": "npx vitest run tests/order.test.ts", "order": 2, "covers": ["price"]}
  ],
  "co_change": ["src/order/invoice.ts"],
  "confidence": "high"   // high if signals 1+4 agree, medium if symbol-only, low if git-history-only
}
```

## Verification-plan contract

- Every changed exported symbol MUST appear in at least one `verify_plan` entry, or the plan is flagged `INCOMPLETE` (never silently dropped).
- `order` respects test-dependency (a test of a dependency runs before a test of its consumer).
- The plan is what the regression-investigator challenger runs; the two agree by construction.
