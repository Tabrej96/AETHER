---
name: adversarial-verification
description: Independent challenger agents that actively try to break an implementation — architecture challenger, code breaker, security attacker, performance critic, regression investigator. None of them may approve; they only produce falsifications.
version: 1.0.0
maturity: stable
license: MIT
budget: 0
capabilities:
  - verification
  - security
prerequisites: []
# Invoked per-task by the verifier workflow; not ambient context.
---

# Adversarial Engineering

## Core rule (why this is different from ECC's "code-reviewer" agent)

ECC's reviewer reads a diff and says "looks good." That's approval by inspection.
AETHER's adversarial agents get **a falsification mandate and a budget**, and their
output is a *falsification attempt with evidence*, not a verdict. A verdict is
only produced by the aggregator, and only after every challenger's budget is spent.

## Challengers (spawned independently, in parallel when isolated)

| Challenger | Mandate | Must produce |
|---|---|---|
| **Architecture challenger** | Find the load-bearing assumption the design rests on; break it. | 1 concrete scenario where the architecture silently fails + the coupling it exposes. |
| **Code breaker** | Enumerate boundary inputs (empty, max, malformed, concurrent) and construct one that makes the new code wrong. | Failing input + actual vs expected. |
| **Security attacker** | Treat all new/changed surfaces as attacker-controlled. Prompt injection via data, secret exfil, command injection, path traversal. | Repro steps OR "no injection path, because <specific reason>". |
| **Performance critic** | Measure, don't estimate. Find the new hot path; measure it; find the regression vs baseline. | Numbers: baseline, candidate, delta, with the measurement command. |
| **Regression investigator** | Run the affected test surface (from impact analysis); find any test the change broke that no one planned to run. | Test IDs + failure evidence. |

## Anti-collusion rules

- Challengers do **not** see each other's work products. Each gets the diff + the spec, nothing else.
- No challenger may edit the codebase. They write findings to `.aether/findings/<task>/`.
- A finding without reproducible evidence (command + output, or scenario + trace) is **invalid** and dropped.
- **Disagreement resolution:** two challengers contradict (e.g. perf critic says "2× faster", regression inv. says "timeout at N") → the *more specific, more measured* claim wins; tie → escalate to human, never to the implementing agent.
- A challenger that returns "nothing to falsify" must still list the 3 riskiest assumptions it considered and why they held — silence is not a pass.

## Output

```json
{
  "task": "...", "challenger": "code-breaker",
  "falsified": true,
  "finding": { "claim": "...", "evidence": "cmd: ...; out: ...", "severity": "high" },
  "considered": ["assumption A held because ...", "B held because ..."]
}
```

The aggregator emits `verdict: pass | fail | escalate` only when every challenger returned and every `falsified: true` finding is either refuted by a fix or accepted (blocking release).
