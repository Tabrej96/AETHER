---
name: agent-collaboration
description: Dependency-aware multi-agent delegation. When to spawn (and when NOT to), ownership, conflict prevention, and the handoff contract. The swarm is a tool, not a default.
version: 1.0.0
maturity: stable
license: MIT
budget: 0
capabilities:
  - coordination
prerequisites: []
---

# Dynamic Agent Swarm

## Spawn decision (the anti-over-spawning rule)

Spawn a parallel agent **only** when ALL hold:
1. Work has **≥2 independent subtasks** that touch **disjoint file sets** (verify with impact analysis; shared files → serialize, don't parallelize).
2. Each subtask is **> ~20 estimated tool calls**; below that, the coordination cost exceeds the work.
3. A subtask is **read-parallel-safe** (two writers never touch the same files — the conflict rule below).

Otherwise: one agent, one pass. Most tasks are not swarm tasks.

## Ownership & conflict prevention

- Every delegated task gets a **file-set lease** (the paths it may write). Leases are checked at delegation time; overlapping leases are split or serialized automatically.
- **Writes are exclusive, reads are free.** Any agent may read any file; only the lease-holder writes the leased paths.
- One agent per lease. A "helper" that just answers a question is a *tool call to yourself* (search/grep), not a subagent.

## Delegation brief (minimum viable handoff)

A delegation prompt must contain, or the spawn is malformed:
- **Goal** (one sentence) + **definition of done** (the gate: test IDs, command, evidence).
- **File-set lease** (explicit paths or glob).
- **What's already ruled out** (so the child doesn't re-derive).
- **Where to read** (point at files/docs, don't paste).
- **No-edit zones** (protected files, e.g. config, CI, credentials).

## Disagreement resolution

| Conflict | Resolution |
|---|---|
| Two agents propose different designs | The one with a *measured* result wins; both only argued → the higher-capability model arbitrates, and the decision is written as an ADR with both options recorded. |
| Implementer vs adversarial challenger | Challenger findings block; implementer must falsify-or-fix (see [[adversarial-verification]]). |
| Test result vs claimed result | The test result. Always. "It works on my run" is a `working`-layer memory, not verified. |

## Failure recovery

- A failed subagent's findings still arrive (its transcript is the record); retry the *task*, not the *agent identity*.
- 2 consecutive failures on the same subtask → escalate: stop delegating, do it inline, and record the failure in memory (`failure` layer).
