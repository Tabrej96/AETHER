# Third-Party Credits & License Compliance

AETHER is an original work. We deliberately do **not** copy ECC's files, but we studied its
architecture and license terms to inform this project. Where we integrate external projects,
each is listed here with license, what we use, and what we credit.

## Studied (architecture reference only — no code copied)

| Project | License | What we studied |
|---|---|---|
| [Everything Claude Code (ECC)](https://github.com/affaan-m/ECC) | MIT © 2026 Affaan Mustafa | Harness taxonomy (agents/skills/rules/hooks), skill format conventions, hook event mapping, install-time security (`--ignore-scripts`). We improved on: self-contained testable hooks, registry-driven curation, context-cost measurement, benchmark reproducibility. |
| [Claude Code Agent Skills spec](https://code.claude.com/docs/en/skills) | MIT | Skill frontmatter fields (`name`, `description`), `context: fork` semantics. |

## Integrated

| Project | License | Usage in AETHER |
|---|---|---|
| Node.js runtime | MIT | `bin/aether` CLI, hook scripts, benchmark runner. No dependencies — AETHER core is dependency-free JS so it runs anywhere Node does. |
| [graphify](https://github.com/erikaraga/graphify) (optional) | See its repo | Optional call-graph/AST signal for the impact-analysis skill. AETHER degrades gracefully without it. |
| User's project toolchain | — | Linters, test runners, and diff tools are invoked read-only by hooks; never modified. |

## Policy

1. Any future vendored code keeps its original license in `THIRD-PARTY.md` (or a `LICENSE-<name>` file at the vendored path).
2. Co-processes are MIT/BSD/Apache-compatible; we check licenses **before** integrating, never after.
3. This file is validated by `tests/third-party.test.mjs` (every integration must be listed).
