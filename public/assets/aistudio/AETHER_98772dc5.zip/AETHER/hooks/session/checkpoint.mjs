#!/usr/bin/env node
// checkpoint.mjs — SessionEnd / PreCompact continuity checkpoint.
//
// Implements the zero-loss continuity protocol: at stage boundaries and at
// session end, write .aether/state.json so the next session (new model, new
// terminal, new machine) can resume deterministically.
//
// Reads stdin JSON (SessionEnd provides {transcript_path, ...} or nothing we
// need). State is gathered from:
//   - git status (branch, dirty?)
//   - .aether/state.json (previous seq → must be incremented, never lowered)
//   - .aether/plan.json (open/verified gates if present)
// Pure function `buildState` is exported and unit-tested.

import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

export function gitFacts(cwd) {
  try {
    const branch = execFileSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    const dirty = execFileSync('git', ['status', '--porcelain'], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim().length > 0;
    return { branch, head, dirty };
  } catch {
    return { branch: null, head: null, dirty: false };
  }
}

export function buildState(cwd, { now = new Date().toISOString() } = {}) {
  const stateDir = join(cwd, '.aether');
  const stateFile = join(stateDir, 'state.json');
  const prev = existsSync(stateFile) ? safeRead(stateFile) : null;
  const facts = gitFacts(cwd);
  let plan = null;
  try { plan = safeRead(join(stateDir, 'plan.json')); } catch { /* no plan */ }
  const seq = (prev?.seq ?? 0) + 1; // monotonic; resume rejects seq <= last on-disk
  const state = {
    seq,
    branch: facts.branch,
    head_commit: facts.head,
    working_tree_dirty: facts.dirty,
    stage: prev?.stage ?? 'unknown',
    open: (plan?.open ?? prev?.open ?? []).map((o) => (typeof o === 'string' ? { id: o, desc: o, status: 'open' } : o)),
    verified: (plan?.verified ?? prev?.verified ?? []).filter((v) => v.evidence), // evidence-only
    discovered: prev?.discovered ?? [],
    updated_at: now,
  };
  return { state, dir: stateDir };
}

function safeRead(p) { return JSON.parse(readFileSync(p, 'utf8')); }

function main() {
  const cwd = process.env.AETHER_CWD ?? process.cwd();
  const { state, dir } = buildState(cwd);
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'state.json'), JSON.stringify(state, null, 2) + '\n');
  // Leave a one-line marker a new session's start-of-task hook can pick up.
  writeFileSync(join(dir, 'last-checkpoint.txt'), `seq=${state.seq} at ${state.updated_at}\n`);
  process.stdout.write(`checkpoint: seq=${state.seq} branch=${state.branch ?? '-'} open=${state.open.length} verified=${state.verified.length}\n`);
}

if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split('/').pop())) main();
