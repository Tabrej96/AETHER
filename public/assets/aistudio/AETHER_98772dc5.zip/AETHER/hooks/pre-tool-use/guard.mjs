#!/usr/bin/env node
// guard.mjs — PreToolUse guard. One entrypoint, pure functions, fully tested.
//
// Contrast with ECC: ECC's hooks.json embeds ~1.5KB of inline JS to locate its
// own install dir on every hook fire. Here: the harness passes the repo root
// via env (AETHER_ROOT) set once at install; the hook is a plain, unit-tested
// script. Faster, deterministic, and the tests in tests/hooks.guard.test.mjs
// prove the behavior.
//
// Reads a JSON payload on stdin: { tool_name, tool_input, cwd }
// Emits a decision on stdout: { "decision": "block"|"allow", "reason": "..." }
// (block = hook stops the tool call with the reason shown to the model.)

import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';

export const BLOCK_PATTERNS = [
  { re: /\bgit\s+push\s+.*--force\b/i, why: 'force push rewrites shared history' },
  { re: /\brm\s+-[a-z]*[rf][a-z]*\s+\/(\s|$)/i, why: 'recursive delete of filesystem root' },
  { re: /:\s*\(\)\s*\{[^}]*:/, why: 'fork-bomb pattern' },
  { re: /\bgit\s+reset\s+--hard\s+HEAD~/i, why: 'hard reset discards commits' },
  { re: /\bdocker\s+system\s+prune\s+-[a-z]*f/i, why: 'docker prune -f deletes all unused images/volumes' },
  { re: /\bDROP\s+(TABLE|DATABASE)\b/i, why: 'destructive DDL (DROP TABLE/DATABASE)' },
  { re: /\bTRUNCATE\s+(TABLE\s+)?\w/i, why: 'TRUNCATE is non-transactional and destructive' },
];

export const SECRET_FILE_PATHS = [
  /\.env(\.|$)/i,
  /id_rsa$|id_ed25519$/i,
  /credentials|\.netrc|\.pypirc/i,
  /kubeconfig$/i,
  /token\.json|api_?key\.(json|ya?ml?)$/i,
];

// Pure: decide for a given payload. Exported so tests call it directly.
export function decide(payload, { isGitRepo = false } = {}) {
  const tool = payload.tool_name ?? '';
  const input = payload.tool_input ?? {};
  const cmd = typeof input.command === 'string' ? input.command : '';
  const path = input.file_path ?? input.path ?? '';

  // 1. Block destructive shell patterns.
  for (const p of BLOCK_PATTERNS) if (p.re.test(cmd)) return block(`blocked: ${p.why}`);
  // 2. Block secret-file writes/reads.
  if (path && SECRET_FILE_PATHS.some((re) => re.test(path))) {
    return block(`blocked: ${path} matches a secret-file pattern; do not read or write credentials`);
  }
  // 3. git commands that are safe to inspect but risky — allow with warning.
  if (/^\s*git\s+commit\b/.test(cmd) && !/--no-verify/i.test(cmd)) {
    return allow('hint: plain commit is fine; use the commit skill to add trailers + conventional type');
  }
  if (/^\s*git\s+push\b/.test(cmd) && isGitRepo) {
    return allow('hint: check you are on a feature branch, not the default branch');
  }
  return allow();
}

function block(reason) { return { decision: 'block', reason }; }
function allow(reason) { return { decision: 'allow', ...(reason ? { reason } : {}) }; }

// ---- main ----
if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split('/').pop())) {
  let raw = '';
  process.stdin.on('data', (d) => (raw += d));
  process.stdin.on('end', () => {
    let payload;
    try { payload = JSON.parse(raw || '{}'); } catch { process.stdout.write(JSON.stringify(block('guard: malformed hook payload'))); return; }
    let isGitRepo = false;
    try {
      if (payload.cwd && existsSync(payload.cwd)) execFileSync('git', ['rev-parse', '--is-inside-work-tree'], { cwd: payload.cwd, stdio: 'ignore' });
      isGitRepo = true;
    } catch { /* not a git repo */ }
    const dec = decide(payload, { isGitRepo });
    process.stdout.write(JSON.stringify(dec));
  });
}
