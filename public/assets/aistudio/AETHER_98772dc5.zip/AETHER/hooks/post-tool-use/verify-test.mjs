#!/usr/bin/env node
// verify-test.mjs — PostToolUse: when a test-runner command just ran, capture
// the pass/fail result into .aether/evidence/ so verifiers grade on evidence.
//
// Trigger: matcher on Bash. Reads stdin JSON {tool_input:{command}, tool_response}.
// If the command looks like a test run and its output is available, writes an
// evidence record. Failing test run → also flags the run so the debug-protocol
// skill knows to start from evidence, not memory.

import { writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const TEST_CMD = /(npm\s+(test|run\s+test)|npx\s+(vitest|jest|mocha|pytest|cargo\s+test|go\s+test)|pytest|go\s+test|cargo\s+test)/i;

export function analyze(command, response) {
  const isTest = typeof command === 'string' && TEST_CMD.test(command);
  if (!isTest) return null;
  const text = typeof response === 'string' ? response : response?.content ?? '';
  const failed = /(\d+)\s+fail(ed|ure)?\b|FAILED|failing/i.test(text);
  const passed = /(\d+)\s+(tests?|checks?)\s+(passed|ok)/i.test(text) && !failed;
  return { isTest, command, passed, failed, ts: new Date().toISOString() };
}

export function recordEvidence(cwd, record) {
  if (!record) return;
  const dir = join(cwd, '.aether', 'evidence');
  mkdirSync(dir, { recursive: true });
  const recs = [];
  try {
    const f = join(dir, 'test-runs.jsonl');
    if (existsSafe(f)) recs.push(readFileSync(f, 'utf8').trimEnd());
  } catch { /* first record */ }
  recs.push(JSON.stringify(record));
  writeFileSync(join(dir, 'test-runs.jsonl'), recs.join('\n') + '\n');
  if (record.failed) writeFileSync(join(dir, 'last-failed.json'), JSON.stringify(record, null, 2) + '\n');
}

function existsSafe(p) { try { return readFileSync(p, 'utf8') !== undefined; } catch { return false; } }

function main() {
  let raw = '';
  process.stdin.on('data', (d) => (raw += d));
  process.stdin.on('end', () => {
    let payload;
    try { payload = JSON.parse(raw || '{}'); } catch { return; }
    const rec = analyze(payload.tool_input?.command, payload.tool_response);
    recordEvidence(process.env.AETHER_CWD ?? process.cwd(), rec);
  });
}

if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split('/').pop())) main();
