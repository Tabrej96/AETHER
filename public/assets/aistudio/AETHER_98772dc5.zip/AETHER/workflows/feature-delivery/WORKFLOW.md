---
name: feature-delivery
description: End-to-end delivery of a feature or fix, from task intake to verified merge, with adversarial verification, memory capture, and continuity checkpoints at every stage boundary.
version: 1.0.0
maturity: stable
budget: 800
license: MIT
capabilities: [workflow, delivery]
prerequisites: [agents/planner, agents/implementer, protocols/adversarial, skills/impact-analysis, skills/checkpoint-resume]
---

# Feature Delivery Workflow

## Entry Conditions
- A task with a definition of done (acceptance criteria the verifier can grade).
- A branch to work on (created or chosen; never the default branch for feature work).
- A checkpoint baseline: `.aether/state.json` seq recorded at entry.

## Stages

| # | Stage | Agent(s) | Gate (evidence) |
|---|---|---|---|
| 1 | **Plan** | planner | `.aether/plans/<task>.json` valid; every stage has a gate; leases disjoint or ordered |
| 2 | **Impact** | impact-analysis skill | verify-plan covers every changed exported symbol; confidence recorded |
| 3 | **Implement** | implementer (per stage, parallel where leases are disjoint) | each stage gate passes; evidence in `.aether/evidence/` |
| 4 | **Adversarial** | code-breaker, security-attacker, performance-critic, regression-investigator (parallel) | findings files present; every `falsified:true` refuted-or-accepted |
| 5 | **Verify & capture** | verifier (aggregator) | verdict `pass`; memory entries written with provenance; next checkpoint written |
| 6 | **Commit + handoff** | commit skill | conventional commit; trailers; state advanced; diff summarized for human |

Stage 4's challengers run in parallel **only** on their read-only findings paths — the
anti-collusion rule means they never see each other's output.

## Dependencies
- Stage 3 stages may parallelize *within* their leases; they serialize on shared files.
- Stage 4 depends on Stage 3's diff existing and staged.
- Stage 5 depends on every Stage 4 challenger having returned (no silent passes).

## Failure Handling
- **Stage 3 gate fails 2×** → debug-protocol skill; a third attempt must follow the hypothesis loop, or the plan stage is re-entered (the plan may be wrong, not just the implementation).
- **Stage 4 critical finding accepted** → back to Stage 3 for that finding; re-run only the affected challengers, not the whole suite.
- **Verifier verdict `escalate`** (challenger disagreement) → human decision recorded as an ADR; the task does not complete silently.
- **Any checkpoint boundary crossed → checkpoint-resume skill writes state before proceeding.**

## Completion
- Verdict `pass` with all evidence in `.aether/evidence/`.
- Memory entries: ≥1 verified for what worked; any refuted hypotheses in the failure layer.
- Final checkpoint written with `stage: released-pending` or `merged`.
- Human sees: the diff summary + the open risks the verifier listed (even when passing, the residual risks are surfaced, not hidden).
