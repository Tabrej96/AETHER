// hooks.guard.test.mjs — the guard hook is the safety boundary; test it hard.
import assert from 'node:assert/strict';
import { decide } from '../hooks/pre-tool-use/guard.mjs';
import { analyze } from '../hooks/post-tool-use/verify-test.mjs';
import { buildState } from '../hooks/session/checkpoint.mjs';
import { mkdtempSync, rmSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const tests = [];
const t = (name, fn) => tests.push([name, fn]);
const P = (command, extra = {}) => ({ tool_name: 'Bash', tool_input: { command, ...extra } });

// ---- guard: destructive blocks ----
t('blocks force push', () => assert.equal(decide(P('git push origin main --force')).decision, 'block'));
t('blocks rm -rf / (both flag orders)', () => {
  assert.equal(decide(P('rm -rf /')).decision, 'block');
  assert.equal(decide(P('rm -fr /')).decision, 'block');
});
t('does not block rm -rf of a project subdir', () => {
  assert.equal(decide(P('rm -rf ./dist')).decision, 'allow');
  assert.equal(decide(P('rm -rf build/')).decision, 'allow');
});
t('blocks git reset --hard HEAD~', () => assert.equal(decide(P('git reset --hard HEAD~2')).decision, 'block'));
t('blocks DROP TABLE', () => assert.equal(decide(P('psql db -c "DROP TABLE users"')).decision, 'block'));
t('blocks docker system prune -f', () => assert.equal(decide(P('docker system prune -f --volumes')).decision, 'block'));
t('blocks the fork bomb', () => assert.equal(decide(P(':(){ :|:& };:')).decision, 'block'));
t('allows plain test runs', () => assert.equal(decide(P('npm test')).decision, 'allow'));
t('hints on plain git commit', () => {
  const d = decide(P('git commit -m "x"'));
  assert.equal(d.decision, 'allow');
  assert.match(d.reason, /hint/);
});
t('blocks reading .env', () => assert.equal(decide({ tool_name: 'Read', tool_input: { file_path: '.env' } }).decision, 'block'));
t('blocks writing a credentials file', () => assert.equal(decide({ tool_name: 'Write', tool_input: { file_path: 'secrets/credentials' } }).decision, 'block'));
t('allows a normal source file', () => assert.equal(decide({ tool_name: 'Write', tool_input: { file_path: 'src/app.ts' } }).decision, 'allow'));
t('blocked reasons are actionable', () => {
  const d = decide(P('git push --force'));
  assert.ok(d.reason.startsWith('blocked:') && d.reason.length > 20);
});

// ---- post-tool verifier ----
t('verifier detects a failing test run', () => {
  const r = analyze('npm test', '3 passing, 1 failing');
  assert.ok(r && r.isTest && r.failed);
});
t('verifier detects a passing test run', () => {
  const r = analyze('npx vitest run', '12 tests passed');
  assert.ok(r && r.passed && !r.failed);
});
t('verifier ignores non-test commands', () => assert.equal(analyze('ls -la', 'output'), null));

// ---- checkpoint ----
t('checkpoint seq is monotonic', () => {
  const tmp = mkdtempSync(join(tmpdir(), 'aether-cp-'));
  try {
    assert.equal(buildState(tmp).state.seq, 1, 'first checkpoint is seq 1');
    mkdirSync(join(tmp, '.aether'), { recursive: true });
    writeFileSync(join(tmp, '.aether/state.json'), JSON.stringify({ seq: 5, open: [], verified: [] }));
    assert.equal(buildState(tmp).state.seq, 6, 'seq is last + 1, never reset');
  } finally { rmSync(tmp, { recursive: true, force: true }); }
});

t('checkpoint keeps evidence-only verified entries', () => {
  const tmp = mkdtempSync(join(tmpdir(), 'aether-cp2-'));
  try {
    mkdirSync(join(tmp, '.aether'), { recursive: true });
    writeFileSync(join(tmp, '.aether/state.json'), JSON.stringify({ seq: 1, open: [], verified: [] }));
    writeFileSync(join(tmp, '.aether/plan.json'), JSON.stringify({
      verified: [{ gate: 'tests pass', evidence: 'npm test, exit 0, commit abc' }, { gate: 'lint' }],
    }));
    const s = buildState(tmp).state;
    assert.equal(s.verified.length, 1, 'verified entries without evidence are dropped');
    assert.match(s.verified[0].evidence, /npm test/);
  } finally { rmSync(tmp, { recursive: true, force: true }); }
});

let failed = 0;
for (const [name, fn] of tests) {
  try { await fn(); console.log(`  ✓ ${name}`); }
  catch (e) { failed++; console.error(`  ✗ ${name}\n    ${e.message}`); }
}
console.log(`${tests.length - failed}/${tests.length} hook tests passed`);
process.exit(failed ? 1 : 0);
