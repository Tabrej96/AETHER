// catalog.test.mjs — the registry is the load-bearing structure; test it hard.
import assert from 'node:assert/strict';
import { buildCatalog, selectComponents, listComponents, loadComponent } from '../lib/catalog.mjs';
import { estimateTokens, staticContextCost, fitWithin, aggregateBudget } from '../lib/context-cost.mjs';

const tests = [];
const t = (name, fn) => tests.push([name, fn]);

t('yaml-lite parses nested frontmatter', () => {
  const c = loadComponent('agents', 'planner');
  assert.equal(c.name, 'planner');
  assert.ok(Array.isArray(c.capabilities));
  assert.ok(c.capabilities.includes('planning'));
  assert.equal(c.budget, 600);
  assert.equal(c.maturity, 'stable');
});

t('catalog builds without warnings for shipped components', () => {
  const { components, warnings } = buildCatalog();
  assert.ok(components.length >= 10, `expected >=10 components, got ${components.length}`);
  assert.equal(warnings.length, 0, `unexpected parse warnings: ${JSON.stringify(warnings)}`);
});

t('every component has a non-empty description and numeric budget where required', () => {
  const { components } = buildCatalog();
  for (const c of components) {
    assert.ok(c.description.length > 20, `${c.id} has a too-short description`);
    if (['agents', 'skills', 'workflows', 'protocols'].includes(c.kind)) {
      assert.ok(Number.isFinite(c.budget), `${c.id} budget not numeric`);
    }
  }
});

t('selectComponents covers needs within budget and defers overflow', () => {
  const { components } = buildCatalog();
  const sel = selectComponents(components, ['continuity', 'recovery', 'memory', 'learning'], { maxTokens: 1200 });
  assert.ok(sel.chosen.length >= 1, 'expected at least one component chosen');
  assert.ok(sel.used <= 1200, `budget overflow: ${sel.used}`);
  // continuity need must be covered by the checkpoint-resume skill
  assert.ok(sel.unmet.length === 0 || sel.deferred.length > 0 || sel.chosen.length > 0);
});

t('estimateTokens is sane', () => {
  const n = estimateTokens('a'.repeat(400));
  assert.ok(n > 90 && n < 110, `400 chars should be ~100 tokens, got ${n}`);
  const cjk = estimateTokens('甲'.repeat(50));
  assert.equal(cjk, 50, 'CJK should be 1 token/char');
});

t('staticContextCost: active component cost is much less than its full body', () => {
  const { components } = buildCatalog();
  const skill = components.find((c) => c.id === 'skills/checkpoint-resume');
  const cost = staticContextCost(skill);
  const bodyCost = estimateTokens(skill.body);
  assert.ok(cost.total < bodyCost, `static ${cost.total} should be < body ${bodyCost}`);
});

t('fitWithin drops lowest-priority (largest) overloads, keeps the rest', () => {
  const { components } = buildCatalog();
  const ids = components.map((c) => c.id);
  const tight = fitWithin(components, ids, 50);
  assert.ok(tight.kept.length < ids.length, 'a 50-token budget must drop most components');
  const keptCost = aggregateBudget(components, tight.kept).total;
  assert.ok(keptCost <= 50, `kept cost ${keptCost} exceeds budget`);
});

t('unmet capabilities are reported, never silently dropped', () => {
  const { components } = buildCatalog();
  const sel = selectComponents(components, ['capability-that-does-not-exist'], { maxTokens: 999999 });
  assert.deepEqual(sel.unmet, ['capability-that-does-not-exist']);
  assert.equal(sel.chosen.length, 0);
});

t('listComponents only returns parseable dirs (skills have SKILL.md)', () => {
  const skills = listComponents('skills');
  assert.ok(skills.length >= 7, `expected >=7 skills, got ${skills.length}`);
});

// ---- runner ----
let failed = 0;
for (const [name, fn] of tests) {
  try { await fn(); console.log(`  ✓ ${name}`); }
  catch (e) { failed++; console.error(`  ✗ ${name}\n    ${e.message}`); }
}
console.log(`${tests.length - failed}/${tests.length} catalog tests passed`);
process.exit(failed ? 1 : 0);
