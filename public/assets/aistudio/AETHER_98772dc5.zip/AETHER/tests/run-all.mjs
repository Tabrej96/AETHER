#!/usr/bin/env node
// run-all.mjs — runs every *.test.mjs in tests/ and reports.
import { readdirSync } from 'node:fs';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const dir = fileURLToPath(new URL('.', import.meta.url));
const files = readdirSync(dir).filter((f) => f.endsWith('.test.mjs'));
let failed = 0, total = 0;
for (const f of files) {
  total++;
  process.stdout.write(`\n=== ${f} ===\n`);
  try {
    execFileSync(process.execPath, [join(dir, f)], { stdio: 'inherit' });
  } catch {
    failed++;
  }
}
console.log(`\n${total - failed}/${total} test files passed`);
process.exit(failed ? 1 : 0);
