---
name: impact-analysis
description: Before implementing a change, estimate what it will touch (imports, symbols, tests, co-change history) and produce the targeted verification plan. Makes "which tests to run" deterministic instead of a guess.
version: 1.0.0
maturity: experimental
budget: 600
license: MIT
capabilities: [impact-analysis]
prerequisites: [protocols/impact]
---

# Change Impact Analysis

## When to Activate
- Before any non-trivial edit that changes an exported symbol, a public API, or a shared module.
- Before running the adversarial suite (the regression investigator's test list comes from here).

## Inputs
- The diff (or the files you intend to change).
- Repo: import graph, test files, git history.

## Procedure (signal ladder — cheapest first, stop when confident)
1. **Imports of changed files** → direct consumers. (grep import/require lines for the module path.)
2. **Exported symbols in changed files** → grep their use sites across the repo.
3. **Test-dependency map** → for each affected symbol, find tests importing its module or asserting on it. Those are your verify-plan.
4. **Git co-change** → `git log --name-only` windows where the changed files were edited; files that always change together are coupling you must check.
5. **Confidence:** high = signals 1+4 agree; medium = symbol-grep only; low = co-change only → flag the verify-plan `INCOMPLETE`, run the full suite.

## Outputs
```json
{"affected":[...], "verify_plan":[{"cmd":"...","order":1,"covers":[...]}], "confidence":"high"}
```
Contract: every changed exported symbol appears in ≥1 verify-plan entry, else `INCOMPLETE`.

## Verification
- Spot-check: the verify-plan, when executed, is the set the regression-investigator would need.
- In benchmarks, this skill's output is scored against the ground-truth affected set (precision/recall).

## Failure cases
- Monorepo: scope the grep to the affected workspace, else signal 2 explodes.
- No tests for a changed symbol → that's a finding (untested surface), not a skip.
