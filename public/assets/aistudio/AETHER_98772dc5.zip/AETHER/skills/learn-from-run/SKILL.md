---
name: learn-from-run
description: Controlled continuous learning: after a verified task, extract the reusable decision + its provenance into the memory layers; promote to a pattern only after N independent verifications. Learning is audited, never silent.
version: 1.0.0
maturity: experimental
budget: 500
license: MIT
capabilities: [learning, memory]
prerequisites: [protocols/memory]
---

# Self-Improving Engineering Knowledge

## When to Activate
- A task finished with new verified evidence (a gate passed, a falsification was refuted, a fix was confirmed).
- A failure was root-caused (the failure layer is the highest-value memory — record it).

## Procedure
1. **Extract.** One claim per entry. Bad: "that worked better". Good: "running test-dep-ordered verify plans cut regressions vs full-suite in N tasks" — a claim with a measurable predicate.
2. **Provenance, or it doesn't exist.** Every entry carries: task id, run, evidence pointer (file + command + commit). No provenance → not written.
3. **State = working.** Only the verifier path (a second, independent confirmation) may set `verified`.
4. **Pattern promotion.** Two independent verified entries with the same claim+scope → one `pattern` entry, both provenance links kept.
5. **Decay check.** Entries unverified in 30 days → demote + re-queue. `failure` entries never decay.
6. **Skill/rule feedback loop.** If a learning says "rule X was wrong on Y class", file it as a rule-PR draft under `.aether/learning/proposals/` — a human or the verifier merges it. Skills never rewrite themselves silently.

## Verification
- Each extracted claim is checkable by re-running its evidence command.
- Promotion happened via two independent runs, not one run twice.

## Failure cases
- Claim is too broad ("X is better than Y") → narrow to the task class where it was verified.
- Two runs were not independent (same session, same data) → they don't coalesce.
