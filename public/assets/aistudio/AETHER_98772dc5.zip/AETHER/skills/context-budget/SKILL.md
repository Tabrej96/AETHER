---
name: context-budget
description: Keep the working context lean: know how much active context you are carrying, defer large reads, compress what you have, and checkpoint before exhaustion. Context is a budget, not a landfill.
version: 1.0.0
maturity: stable
budget: 400
license: MIT
capabilities: [context-efficiency]
prerequisites: [protocols/continuity]
---

# Context Budgeting

## When to Activate
- Context usage looks like it's trending toward a long task's needs (you're re-reading files, output is getting long).
- Before any batch operation that will pull in many large files.

## Procedure
1. **Measure.** Know your window and current load. (Ask the harness, or estimate: system + each tool result you've kept.)
2. **Defer.** Prefer `grep`/`glob` summaries over full reads; read the top of large files, not all of them. Pull more only when the task needs it.
3. **Compress.** Replace kept file contents with the facts you extracted (line refs, decisions, signatures) — a 40-line note beats a 400-line re-read.
4. **Checkpoint.** When the task crosses a stage boundary, run the checkpoint-resume skill: write state, drop the verbose tool outputs, keep the summary.
5. **Never lose evidence.** Gate outputs and test results go to `.aether/evidence/` (disk), not held in context.

## Verification
- After compaction, a resume from checkpoint succeeds: the open/verified lists match what the task actually needed.
- No re-derivation: the compacted session didn't re-run already-verified steps.

## Failure cases
- Compressing away a still-open item's evidence → the open item's evidence must survive compaction (it's in state.json; keep it there, not in context).
- Budget math wrong → the checkpoint skill's evidence log tells you what you actually spent.
