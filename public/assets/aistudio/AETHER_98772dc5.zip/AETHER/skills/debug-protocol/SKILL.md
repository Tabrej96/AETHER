---
name: debug-protocol
description: A disciplined debug loop: reproduce → evidence → hypothesis → test → root cause → minimal fix → verify → record. No guessing, no thrashing. Use on any failure that didn't fix on the first try.
version: 1.0.0
maturity: stable
budget: 600
license: MIT
capabilities: [debugging]
prerequisites: [memory]
---

# Autonomous Debugging Protocol

## When to Activate
- A failure reproduced less than once. Before ANY fix attempt, complete the Reproduce step.
- The second fix attempt on the same failure is about to start (this is the thrash detector — stop, follow the protocol).

## Procedure
1. **Reproduce.** Write the exact command that fails. Record the failure evidence to `.aether/evidence/`. A bug you can't reproduce is a bug you can't verify you've fixed.
2. **Gather.** Collect: the failing input, expected vs actual, stack trace, the last commit that might have changed this behavior (`git log -5 -- <file>`).
3. **Hypothesis.** State it in one sentence, falsifiable: "X causes Y because Z." (Z must be a mechanism, not a vibe.)
4. **Test the hypothesis cheaply.** Smallest experiment: a one-line probe, a targeted unit test, a minimal repro. NOT a refactor.
5. **Root cause.** The hypothesis is confirmed when the experiment's outcome differs *exactly* in the predicted way. Anything else → new hypothesis, same loop.
6. **Minimal fix.** Change the minimum that addresses the root cause. If the fix needs > 5 files, you don't have the root cause yet.
7. **Verify.** Re-run the reproducer AND the impact-analysis verify-plan (the change may break neighbors).
8. **Record.** Memory entry: claim + provenance (this task, repro command, commit) + state `verified`. If the hypothesis was refuted, record that in the `failure` layer with the delta.

## Verification
- The original reproducer now passes (evidence captured).
- Impact verify-plan passes.
- A memory entry exists linking claim → evidence.

## Failure cases
- No reproducible command (intermittent) → capture the conditions that trigger it (race: run N=50×; env: note the deltas).
- Root cause is out of your control (external API) → record the boundary, propose a mock/stub + alerting, don't patch around it silently.
