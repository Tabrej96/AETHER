---
name: security-review
description: Pre-commit security pass: injection vectors, secret handling, path traversal, dependency posture, and prompt-injection defense for agentic code. Fast when clean, thorough when the diff touches untrusted input.
version: 1.0.0
maturity: stable
budget: 500
license: MIT
capabilities: [security]
prerequisites: [rules/security, agents/security-attacker]
---

# Security Review

## When to Activate
- Before committing a diff that handles: user input, file paths, shell strings, external data, credentials, or new dependencies.
- Periodically on repos that fetch and act on untrusted content (the agentic-code injection class).

## Procedure (cheap-first triage, then depth where risk is)
1. **Triage** (<30 s): Does the diff touch any attack-surface category above? If no → note "no security surface changed" and stop.
2. **Vectors** (run each against the diff, record findings):
   - Shell built from strings → command injection. Fix: argv arrays, no shell=true on untrusted.
   - User paths in read/write/unzip → traversal. Fix: resolve + prefix-check against the intended root.
   - New logging/error paths → secret exfil. Fix: scrub before emit.
   - Untrusted content into an LLM prompt or agent tool result → prompt injection. Fix: sandbox, or wrap in clearly-marked untrusted blocks; never let it reach a privileged tool path without validation.
   - New deps → license + supply chain (scripts-on-install). Fix: `--ignore-scripts` where safe; pin; record in THIRD-PARTY.md.
   - Deserialization of untrusted input → no eval/JSON-into-exec paths.
3. **Severity:** critical (secret exfil, RCE path), high (traversal, injection reachable from network), medium (defense-in-depth gap), low (style).
4. **Fix-or-record:** each critical/high must be fixed in this diff or explicitly tracked.

## Outputs
- Findings list: vector, repro, severity, fix-or-tracker.
- Clean-pass note: "no path" reasons, not silence.

## Verification
- For each fix: the reproducer step no longer succeeds (you ran it).
- Prompt-injection findings: verify with the exact untrusted input that reached the code, not a paraphrase.

## Failure cases
- A "fix" that just blocks the one tested input → note the general class, not the instance.
- No time to fix critical → the diff does not go to review; say so.
