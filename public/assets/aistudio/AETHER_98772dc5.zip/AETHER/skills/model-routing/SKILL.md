---
name: model-routing
description: Provider-agnostic model selection: route by task class using the measured model ledger in .aether/models.json, not by habit. High-reasoning for adversarial/design, balanced for execution, cheap for mechanical work.
version: 1.0.0
maturity: stable
budget: 400
license: MIT
capabilities: [model-strategy]
prerequisites: [benchmarks/model-ledger]
---

# Adaptive Model Intelligence

## When to Activate
- Choosing which model runs an agent (frontmatter `model-hint`), when the task class is non-obvious.
- After benchmarks update `.aether/models.json` — routing should follow the ledger.

## Routing table (defaults, overridden by the ledger's measured results)

| Task class | Default hint | Why |
|---|---|---|
| Architecture, adversarial falsification, security threat-modeling | high-reasoning (top model) | These scale with raw reasoning; cheap models measurably miss classes here. |
| Implementation, test writing, refactors | balanced | Reliability + idiomaticity matter more than max reasoning; the gate catches errors. |
| Mechanical: format, rename, dependency bump, commit trailers | cheap/fast | No reasoning content; speed + cost win. |
| Long-context retrieval triage | high-context (large window, cheap-ish) | Retrieval quality is a context-length problem, not a reasoning one. |

## Ledger contract (`.aether/models.json`)
```json
{"models":[
  {"id":"...","provider":"...","task_class":"adversarial",
   "success_rate":0.9,"cost_per_1k":0.003,"latency_ms":2100,
   "n_trials":12,"last_measured":"2026-11-01"}
]}
```
Route = highest `success_rate` within the token budget, tiebreak on cost. Entries with `n_trials < 8` are ranked **below** proven models with ≥8 trials — a small sample never outranks a solid one.

## Verification
- A routing decision cites the ledger entry it used (or the default row, and why the ledger didn't apply).
- After a task completes, the runner records its outcome for the model+task-class used — the ledger is how routing gets measured.

## Failure cases
- Ledger stale (>60 days for a task class) → run the benchmark suite for that class before trusting its routing.
- Provider unavailable → fall to the next row's best measured provider, log the substitution.
