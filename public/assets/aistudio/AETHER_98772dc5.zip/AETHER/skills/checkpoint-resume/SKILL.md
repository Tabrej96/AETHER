---
name: checkpoint-resume
description: Resume an interrupted task from .aether/state.json — the zero-loss continuity protocol. Use at session start when a checkpoint exists, and before any long task to know where you stopped.
version: 1.0.0
maturity: stable
budget: 500
license: MIT
capabilities: [continuity, recovery]
prerequisites: [protocols/continuity]
---

# Checkpoint & Resume

## When to Activate
- A session starts in a repo containing `.aether/state.json` (check first — it's one stat call).
- Context runs low and you must compact: checkpoint before the compaction, not after.
- A task was interrupted (terminal closed, API failure, branch change).

## Procedure
1. `cat .aether/last-checkpoint.txt` → `seq`, timestamp. Cheap: one line.
2. Load `.aether/state.json`. Confirm `seq` is the max of any `state/checkpoint-*.json` (monotonic check; a lower seq means a stale/corrupt file — warn, don't trust).
3. **Branch guard**: if `state.branch != current branch`, STOP and tell the user. Never auto-switch.
4. Replay `open` items: for each, run its verification command if it's cheap (<30 s); otherwise re-plan that item via the planner agent.
5. Hand the model a **compact summary** (task, stage, open[], verified[] with evidence) — not the full history. History lives in `state/` and is pulled on demand.

## Verification
- Resumed work passes the same gate it was stopped at (a resumed task's gates are unchanged — that's the point).
- `seq` advances by exactly 1 on the next checkpoint.

## Failure cases
- `state.json` corrupt → fall back to the newest `checkpoint-*.json`, log the gap.
- Missing `evidence` on a "verified" entry → treat as unverified (the protocol is evidence-only).
- Open item references a file that no longer exists → re-derive it from impact analysis, don't assume.

## Context cost
Static: ~500 tokens (this skill's frontmatter + section headers when active).
Dynamic: one state.json read per activation (~200 tokens typical).
