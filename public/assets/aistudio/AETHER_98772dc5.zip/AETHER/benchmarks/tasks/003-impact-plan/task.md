# Task 003 — Change-impact verification plan

Repo: `benchmarks/fixed/003-impact-plan` (a small JS project with real import coupling).

The developer is about to change the exported symbol `formatPrice` in
`src/price.js`. Produce a **verification plan** in `.aether/impact.json`
inside that repo, matching the shape in `protocols/impact`:

```json
{
  "affected": [ {"file": "...", "reason": "...", "signal": "import|symbol|test-dep|co-change"} ],
  "verify_plan": [ {"cmd": "...", "order": 1, "covers": ["..."]} ],
  "confidence": "high|medium|low"
}
```

The plan must (a) list every file that imports or otherwise depends on
`formatPrice`, and (b) for each, the test command that exercises it, in
dependency order. Every changed exported symbol must appear in ≥1
`verify_plan` entry, else the plan is `INCOMPLETE`.

Definition of done: the grader's precision/recall against the fixture's
ground-truth affected set is ≥ 0.8, and every affected test is covered.
