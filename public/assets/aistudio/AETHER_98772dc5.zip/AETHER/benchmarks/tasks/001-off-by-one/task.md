# Task 001 — Off-by-one in pagination

Repo: `benchmarks/fixed/001-off-by-one` (a small Node project, run `npm test` after your change).

`src/paginate.ts` returns page N of `items` with `perPage` per page. The test suite
currently fails on two tests. Find the bug and fix it with a **minimal diff**. Do not
change the public API. Do not touch tests.

Definition of done: `npx vitest run` passes all tests.
