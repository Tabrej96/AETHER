// check.mjs — deterministic grader for 001-off-by-one.
// Runs the (possibly fixed) src/paginate.ts in a clean Node (native TS) and
// scores against the spec. No test-runner dependency: the grader IS the test.
// `outDir` must contain the fixed repo root (or set AETHER_BENCH_OUT).
export async function grade({ outDir }) {
  const { pathToFileURL } = await import('node:url');
  const { join: pjoin } = await import('node:path');
  const src = outDir ?? process.env.AETHER_BENCH_OUT ?? 'fixed/001-off-by-one';
  // Windows ESM requires file:// URLs for absolute paths; relative is fine if CWD is set.
  const modUrl = pathToFileURL(pjoin(src, 'src/paginate.ts')).href;
  const mod = await import(modUrl).catch(() => null);
  if (!mod?.paginate) return { pass: false, metrics: { tests_passed: 0, tests_total: 5 } };

  const items = Array.from({ length: 10 }, (_, i) => i);
  const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const checks = [
    { name: 'page1_index0', ok: eq(mod.paginate(items, 1, 5).items, [0, 1, 2, 3, 4]) },
    { name: 'page2_index5', ok: eq(mod.paginate(items, 2, 5).items, [5, 6, 7, 8, 9]) },
    { name: 'filled_last_page_total', ok: mod.paginate(items, 2, 5).totalPages === 2 },
    { name: 'partial_last_page', ok: mod.paginate(items.slice(0, 8), 2, 5).totalPages === 2 && eq(mod.paginate(items.slice(0, 8), 2, 5).items, [5, 6, 7]) },
    { name: 'page1_no_prev', ok: mod.paginate(items, 1, 5).hasPrev === false },
  ];
  const passed = checks.filter((c) => c.ok).length;
  return {
    pass: passed === checks.length,
    metrics: {
      tests_passed: passed,
      tests_total: checks.length,
      // reward minimal diffs: count changed lines in src/paginate.ts vs original
      ...(await minimalDiffScore(src, checks.filter((c) => !c.ok).map((c) => c.name))),
    },
  };
}

async function minimalDiffScore(src, failingNames) {
  try {
    const { readFileSync } = await import('node:fs');
    const cur = readFileSync(`${src}/src/paginate.ts`, 'utf8');
    const original = cur.replace(/\(page - 1\) \* perPage/g, 'page * perPage').replace(/Math\.ceil\(/g, 'Math.floor(');
    // Heuristic: if a fix is present, changed lines vs original form.
    const a = original.split('\n'), b = cur.split('\n');
    let changed = 0;
    for (let i = 0; i < Math.max(a.length, b.length); i++) if (a[i] !== b[i]) changed++;
    return { changed_lines: changed, minimal_diff: changed <= 3 ? 1 : 0.5, still_failing: failingNames.join(',') || 'none' };
  } catch {
    return { changed_lines: null, minimal_diff: 0.5 };
  }
}
