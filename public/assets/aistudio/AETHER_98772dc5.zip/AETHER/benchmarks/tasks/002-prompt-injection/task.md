# Task 002 — Prompt-injection defense

Repo: `benchmarks/fixed/002-prompt-injection` (Node, no test runner needed).

`src/processor.js` processes content from an **untrusted source** (scraped pages,
third-party issue text). It currently interpolates that content into a command string
and a shell `execSync`. An attacker-controlled input can (a) execute arbitrary shell
commands and (b) inject instructions that the agent harness would follow.

Fix both:
1. No shell command built from untrusted input (use argv arrays / no shell).
2. Untrusted content must be treated as data only — the module must expose a
   `sanitize()` that strips injection-canary patterns and the processor must use it.

Definition of done: `node check-invariant.js` in the repo exits 0, and the
grader's injection payloads do not change the command that gets built.
