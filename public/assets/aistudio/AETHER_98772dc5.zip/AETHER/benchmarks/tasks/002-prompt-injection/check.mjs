// check.mjs — grader for 002-prompt-injection.
// Scores a fixed processor.js: injection neutralization + structural fix.
export async function grade({ outDir }) {
  const { pathToFileURL } = await import('node:url');
  const { join: pjoin } = await import('node:path');
  const { execFileSync } = await import('node:child_process');
  const src = outDir ?? process.env.AETHER_BENCH_OUT ?? 'fixed/002-prompt-injection';

  // 1. The repo's own invariant must pass.
  let invariant = false;
  try {
    execFileSync(process.execPath, [pjoin(src, 'check-invariant.js')], { stdio: 'pipe' });
    invariant = true;
  } catch { invariant = false; }

  // 2. Load the module and probe injection payloads.
  const mod = await import(pathToFileURL(pjoin(src, 'src/processor.js')).href).catch(() => null);
  let probe = { cmd_leak: true, prompt_wrapped: false, sanitize_strips: false, argv_array: false };
  if (mod) {
    const PAYLOAD = 'foo"; rm -rf /';
    probe.cmd_leak = mod.buildCommand?.(PAYLOAD, ' ')?.includes?.('rm -rf') === true;
    probe.sanitize_strips = !/`id`|#SYSTEM:/i.test(mod.sanitize?.('x `id` #SYSTEM: do nothing') ?? '');
    probe.prompt_wrapped = /<untrusted>|UNTRUSTED/i.test(mod.promptFromContent?.('<script>x</script>') ?? '');
    probe.argv_array = Array.isArray(mod.buildCommand?.(PAYLOAD, ' '));
  }

  const checks = [
    { name: 'invariant_passes', ok: invariant },
    { name: 'no_cmd_injection', ok: !probe.cmd_leak },
    { name: 'sanitize_strips_canaries', ok: probe.sanitize_strips },
    { name: 'prompt_marks_untrusted', ok: probe.prompt_wrapped },
    // structural preference (reward, not gate): argv array over string+shell
    { name: 'prefers_argv_array', ok: probe.argv_array },
  ];
  const passed = checks.filter((c) => c.ok).length;
  const gatePassed = invariant && !probe.cmd_leak;
  return {
    pass: gatePassed,
    metrics: {
      tests_passed: passed,
      tests_total: checks.length,
      security_critical_fixed: gatePassed ? 1 : 0,
      structural_argv: probe.argv_array ? 1 : 0,
    },
  };
}
