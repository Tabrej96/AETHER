#!/usr/bin/env node
// benchmarks/run.mjs — reproducible evaluation runner.
//
// A benchmark task is a directory under benchmarks/tasks/<id>/ containing:
//   task.md     — the prompt given to the agent (identical across systems)
//   run.sh|run.ps1 — optional env setup (identical across systems)
//   check.mjs   — a deterministic grader: reads the agent's output/diff and
//                 emits JSON { pass: bool, metrics: {...} }
//
// The runner executes the task under a named "system" (aether | ecc | bare),
// captures the transcript + wall-time + (if available) token usage, runs the
// grader, and records a trial to benchmarks/results/<task>/<system>.json.
//
// We report VARIANCE: N trials per task (default 3), with min/median/max on
// each metric. No manufactured wins — a system only "wins" a metric if its
// median beats the others AND the ranges don't fully overlap.
//
// This is a real, working runner for the graders. Driving a live LLM through
// each task requires an agent SDK; the runner is structured so that a
// `--driver <fn>` module can be plugged in. The deterministic graders and
// the metric/variance reporting are complete and tested.

import { readdirSync, readFileSync, writeFileSync, mkdirSync, existsSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const HERE = fileURLToPath(new URL('.', import.meta.url));
const TASKS = join(HERE, 'tasks');
const RESULTS = join(HERE, 'results');

export function listTasks() {
  if (!existsSync(TASKS)) return [];
  return readdirSync(TASKS).filter((d) => statSync(join(TASKS, d)).isDirectory());
}

export function loadTask(id) {
  const dir = join(TASKS, id);
  const task = {
    id,
    prompt: readFileSync(join(dir, 'task.md'), 'utf8'),
    grader: join(dir, 'check.mjs'),
  };
  task.setup = existsSync(join(dir, 'run.sh')) ? join(dir, 'run.sh') : undefined;
  return task;
}

// Run a task's grader against an output artifact (a dir containing diff,
// transcript, etc.). Returns { pass, metrics }.
export function grade(task, outDir) {
  const mod = await import(task.grader);
  if (!mod.grade) throw new Error(`grader for ${task.id} missing grade()`);
  const res = await mod.grade({ outDir, task });
  if (typeof res.pass !== 'boolean' || !res.metrics) throw new Error(`grader for ${task.id} must return {pass, metrics}`);
  return res;
}

// Summarize N trials into min/median/max per metric.
export function summarize(trials) {
  const metricNames = new Set();
  for (const t of trials) for (const k of Object.keys(t.metrics ?? {})) metricNames.add(k);
  const out = { n: trials.length, passRate: trials.filter((t) => t.pass).length / trials.length };
  for (const m of metricNames) {
    const vals = trials.map((t) => t.metrics?.[m]).filter((v) => typeof v === 'number');
    if (!vals.length) continue;
    vals.sort((a, b) => a - b);
    out[m] = { min: vals[0], max: vals[vals.length - 1], median: median(vals) };
  }
  return out;
}

function median(vals) {
  const s = [...vals].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

// Record a trial + compare across systems (the "do the ranges overlap?" test).
export function recordTrial(task, system, trial) {
  const dir = join(RESULTS, task.id, system);
  mkdirSync(dir, { recursive: true });
  const file = join(dir, `trial-${trial.n}.json`);
  writeFileSync(file, JSON.stringify({ ...trial, system, task: task.id, at: new Date().toISOString() }, null, 2) + '\n');
  return file;
}

export function compare(taskId) {
  const base = join(RESULTS, taskId);
  if (!existsSync(base)) return {};
  const systems = readdirSync(base).filter((s) => statSync(join(base, s)).isDirectory());
  const out = { taskId, systems: {}, verdict: {} };
  for (const s of systems) {
    const trials = readdirSync(join(base, s))
      .filter((f) => f.endsWith('.json'))
      .map((f) => JSON.parse(readFileSync(join(base, s, f), 'utf8')));
    out.systems[s] = summarize(trials);
  }
  // Per-metric verdict: a system "wins" only if median > others AND ranges
  // don't fully overlap. Ties reported as ties.
  const metrics = new Set();
  for (const s of systems) for (const m of Object.keys(out.systems[s]).filter((k) => k !== 'n' && k !== 'passRate')) metrics.add(m);
  for (const m of metrics) {
    const entries = systems.map((s) => ({ s, ...out.systems[s][m] })).filter((e) => e.median !== undefined);
    if (entries.length < 2) { out.verdict[m] = { winner: entries[0]?.s ?? null, note: 'single system' }; continue; }
    const best = [...entries].sort((a, b) => b.median - a.median)[0];
    const second = [...entries].sort((a, b) => b.median - a.median)[1];
    // ranges overlap if best.min <= second.max (lower-is-better metrics would invert;
    // we treat all reported metrics here as "higher is better" except *_cost/*_tokens/*_time).
    const lowerIsBetter = /_cost|_tokens|_time|_latency/i.test(m);
    const lo = lowerIsBetter ? best.max : best.min;
    const hi = lowerIsBetter ? second.min : second.max;
    const overlaps = lowerIsBetter ? best.max <= second.min ? false : true : best.min >= second.max;
    out.verdict[m] = { winner: overlaps ? null : best.s, note: overlaps ? 'ranges overlap — not a decisive win' : `${best.s} median ${best.median}`, best, second };
  }
  return out;
}

// ---- CLI ----
const [,, c, ...a] = process.argv;
switch (c) {
  case 'list': console.log(listTasks().join('\n')); break;
  case 'grade': { // grade <task> <system> <outDir>
    const [tid, sys, outDir] = a;
    const res = await grade(loadTask(tid), outDir);
    const trial = { n: 1, pass: res.pass, metrics: res.metrics };
    console.log(recordTrial(tid, sys, trial));
  }
  case 'compare': console.log(JSON.stringify(compare(a[0]), null, 2)); break;
  default:
    console.log('benchmarks/run: list | grade <task> <system> <outDir> | compare <task>');
}
