// Buggy target. Two off-by-one defects:
//  1. slice start uses `page` instead of `page - 1` (pages are 1-indexed by API)
//  2. total-pages rounds down, so a fully-filled last page is dropped
export function paginate(items: unknown[], page: number, perPage: number) {
  const start = page * perPage; // BUG: should be (page - 1) * perPage
  const slice = items.slice(start, start + perPage);
  const totalPages = Math.floor(items.length / perPage); // BUG: should be ceil
  return {
    items: slice,
    page,
    perPage,
    totalPages,
    hasNext: page < totalPages,
    hasPrev: page > 1,
  };
}
