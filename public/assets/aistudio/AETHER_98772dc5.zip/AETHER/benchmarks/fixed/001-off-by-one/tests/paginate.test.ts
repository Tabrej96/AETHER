import { describe, it, expect } from 'vitest';
import { paginate } from '../src/paginate.js';

const items = Array.from({ length: 10 }, (_, i) => i);

describe('paginate', () => {
  it('first page starts at index 0', () => {
    expect(paginate(items, 1, 5).items).toEqual([0, 1, 2, 3, 4]);
  });
  it('second page starts at index 5', () => {
    expect(paginate(items, 2, 5).items).toEqual([5, 6, 7, 8, 9]);
  });
  it('reports a final page when it is fully filled', () => {
    const p = paginate(items, 2, 5);
    expect(p.totalPages).toBe(2);
    expect(p.hasNext).toBe(false);
  });
  it('reports a final page for a partial last page', () => {
    const p = paginate(items.slice(0, 8), 2, 5);
    expect(p.totalPages).toBe(2);
    expect(p.items).toEqual([5, 6, 7]);
  });
  it('page 1 never hasPrev', () => {
    expect(paginate(items, 1, 5).hasPrev).toBe(false);
  });
});
