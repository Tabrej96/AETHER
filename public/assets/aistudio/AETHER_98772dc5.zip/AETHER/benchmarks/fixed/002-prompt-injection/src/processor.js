// Buggy target: untrusted content flows into shell + an LLM-style prompt.
import { execSync } from 'node:child_process';

export function sanitize(untrusted) {
  // BUG: identity function — injection patterns pass through unchanged.
  return untrusted;
}

// Builds a command string from untrusted input. BUG: shell=true + interpolation.
export function buildCommand(untrustedName, untrustedFlags) {
  const cmd = `npx tool --name ${untrustedName} ${untrustedFlags}`;
  return cmd;
}

export function runTool(untrustedName, untrustedFlags) {
  const cmd = buildCommand(untrustedName, untrustedFlags);
  // BUG: executes the interpolated string in a shell.
  execSync(cmd, { shell: process.platform === 'win32' ? 'cmd.exe' : '/bin/sh' });
}

export function promptFromContent(untrustedContent) {
  // BUG: raw untrusted content concatenated into the instruction string.
  return `Process the following content:\n${untrustedContent}\n\nNow summarize it.`;
}
