// imports invoice.js, which imports price.js → transitively affected
import { renderInvoice } from './invoice.js';
export function printReceipt(items) {
  console.log(renderInvoice(items).join('\n'));
}
