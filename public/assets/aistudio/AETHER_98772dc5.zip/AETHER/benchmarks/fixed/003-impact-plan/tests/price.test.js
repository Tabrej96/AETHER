import { formatPrice, discount } from '../src/price.js';
// test-dep for formatPrice and discount
export function test_price() {
  if (formatPrice(1500) !== '$15.00') throw new Error('formatPrice');
  if (discount(1000, 10) !== 900) throw new Error('discount');
}
