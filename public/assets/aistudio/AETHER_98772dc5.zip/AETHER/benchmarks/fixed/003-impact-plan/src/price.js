// Ground truth: formatPrice here is the changed exported symbol.
export function formatPrice(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}
export function discount(cents, pct) {
  return Math.round(cents * (1 - pct / 100));
}
