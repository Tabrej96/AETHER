// imports formatPrice → affected (import signal)
import { formatPrice, discount } from './price.js';
export function renderInvoice(items) {
  return items.map((i) => `${i.name}: ${formatPrice(discount(i.cents, i.discount))}`);
}
