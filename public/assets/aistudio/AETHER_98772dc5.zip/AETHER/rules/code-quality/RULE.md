---
name: code-quality-rules
description: The quality bar every gate enforces: minimal diffs, tested changes, no new dead code, conventional commits, and the evidence requirement for "done."
version: 1.0.0
maturity: stable
license: MIT
---

# Code Quality Rules

## Rule

1. **Minimal diff.** A change contains only what its stage requires. Refactors without a
   stage line are separate tasks.
2. **Every behavior change ships with a test** (new or amended) that fails without the change.
   A test that passes with and without the change is not a test of the change.
3. **No new dead code.** A symbol no one calls is a liability; delete or justify.
4. **Conventional commit** (`type: summary`, body with "why", trailers). The commit skill
   generates the type from the diff; the human-approval gate catches mis-typing.
5. **"Done" requires evidence.** A gate passes only with the captured command + exit code
   (or test IDs + results). "It works" is not done.
6. **Errors are handled or escalated, never swallowed.** An empty `catch {}` or a
   `|| true` that hides failure is a quality finding.
