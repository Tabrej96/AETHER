---
name: context-efficiency-rules
description: The rules that keep AETHER sessions cheap: summaries over dumps, on-demand pulls over ambient context, evidence on disk over held-in-context, and the compaction contract.
version: 1.0.0
maturity: stable
license: MIT
---

# Context Efficiency Rules

## Rule

1. **Summaries beat full reads.** Reach for grep/glob counts and line refs before reading
   files in full. Full-read only the files you will edit.
2. **Evidence on disk.** Test output, gate results, and findings live in `.aether/` —
   the working context holds the *pointers* and the *conclusions*, not the raw dumps.
3. **On-demand over ambient.** A component's full body is pulled only when the task needs
   it; its frontmatter + section headers are what a session carries while it's active.
4. **Compaction preserves the open set.** When context is compacted, every open item and
   every verified-evidence pointer must survive in `.aether/state.json` (the checkpoint
   skill's job). Compaction that loses an open item is a failure.
5. **Token-cost awareness.** Know the rough cost of what you pull (the catalog's `budget`
   fields exist for this). A 400-line file you don't need is 600 tokens of pollution.
